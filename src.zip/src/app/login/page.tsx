"use client";

import React, { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

import { setAuth } from "@/lib/auth";

import { Card } from "@/ui/components/Card";
import { Input } from "@/ui/components/Input";
import { Button } from "@/ui/components/Button";
import { ErrorBanner } from "@/ui/components/ErrorBanner";
import { FormField } from "@/ui/components/FormField";

type LoginSuccess = {
  access_token?: string;
  token?: string;
  jwt?: string;
  role?: "USER" | "ADMIN";
  user_id?: string;
};

function extractToken(payload: LoginSuccess): string | null {
  return payload.access_token ?? payload.token ?? payload.jwt ?? null;
}

function extractRole(payload: LoginSuccess): "USER" | "ADMIN" | null {
  if (payload.role === "USER" || payload.role === "ADMIN") return payload.role;
  return null;
}

export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const canSubmit = useMemo(() => {
    return email.trim().length > 0 && password.length > 0 && !loading;
  }, [email, password, loading]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;

    setErrorMsg(null);
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      if (!res.ok) {
        if (res.status === 401 || res.status === 403) {
          setErrorMsg(res.status === 403 ? "Account is not enabled yet" : "Invalid email or password");
        } else if (res.status === 500) {
          setErrorMsg("Server error occurred during login. Please check server logs.");
        } else {
          setErrorMsg("Login failed");
        }
        return;
      }

      const data = (await res.json()) as LoginSuccess;

      const token = extractToken(data);
      const role = extractRole(data);

      if (!token || !role) {
        setErrorMsg("Login failed");
        return;
      }

      setAuth({ token, role, userId: data.user_id ?? null });
      router.replace("/tasks");
    } catch (err) {
      console.error("Login network/unknown error:", err);
      setErrorMsg("Cannot reach server");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="w-full">
      {/* Break out of any parent max-width container (AppShell) */}
      <div className="relative left-1/2 right-1/2 w-screen -ml-[50vw] -mr-[50vw]">
        {/* HERO */}
        <div
          className="min-h-[calc(100vh-72px)] w-full"
           
        >
          <div className="mx-auto flex w-full max-w-[1200px] items-center justify-between gap-10 px-8 py-14">
            {/* LEFT marketing panel */}
            <div className="min-w-0 flex-1 text-white">
              <div className="max-w-[640px]">
                 
                <h1 className="mt-3 text-5xl font-extrabold leading-tight">
                  Easy previews
                  
                </h1>

               

                <div className="mt-8 inline-flex w-full max-w-[560px] items-center gap-4 rounded-2xl bg-white/15 px-6 py-5 backdrop-blur">
                  <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/20 text-white">
                    <span className="text-lg font-bold">✓</span>
                  </div>

                  <div className="min-w-0">
                    <div className="text-sm font-semibold">How it works</div>
                    <div className="mt-1 text-sm opacity-90">
                      1) Create a task • 2) Scan QR • 3) Upload photo • 3) Select color for your preview • 4) Let the magic happen
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT login card */}
            <div className="w-[420px] shrink-0">
              <Card className="rounded-2xl">
                <div className="p-6">
                  <div className="mb-5 flex items-center gap-3">
                    <div
                      className="flex h-10 w-10 items-center justify-center rounded-xl text-white"
                      style={{ backgroundColor: "rgb(36,116,245)" }}
                    >
                      
                    </div>
                    <div className="leading-tight">
                      <div className="text-sm font-bold">&nbsp;&nbsp;&nbsp;&nbsp;Sign In</div>
                       
                      
                    </div>
                  </div>

                  {errorMsg ? (
                    <div className="mb-4">
                      <ErrorBanner message={errorMsg} />
                    </div>
                  ) : null}

                 <form onSubmit={onSubmit} className="space-y-3 flex flex-col items-center">
                    <div className="w-[90%]">
                      <FormField label="Email" required>
                        <Input
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          autoComplete="email"
                        />
                      </FormField>
                    </div>

                    <div className="w-[90%]">
                      <FormField label="Password" required>
                        <Input
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          autoComplete="current-password"
                        />
                      </FormField>
                    </div>

                    <div className="w-[50%] pt-4">
                      <div>&nbsp;</div>
                      <Button type="submit" disabled={!canSubmit || loading} className="w-full">
                        {loading ? "Logging in..." : "Login"}
                      </Button>
                    </div>
                    <div className="mt-5 flex items-center justify-between text-sm">
                      <Link href="/register" className="underline opacity-80 hover:opacity-100">
                        Create account
                      </Link>
                      
                    </div>
                  </form>

                  
                </div>
              </Card>
            </div>
          </div>

          {/* Mobile fallback: if screen is too small, allow wrap nicely */}
          <div className="mx-auto hidden max-w-[1200px] px-8 pb-10 md:block" />
        </div>
      </div>
    </div>
  );
}